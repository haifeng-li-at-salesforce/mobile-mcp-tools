/*
 * Copyright (c) 2022-present, salesforce.com, inc.
 * All rights reserved.
 * Redistribution and use of this software in source and binary forms, with or
 * without modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * - Neither the name of salesforce.com, inc. nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission of salesforce.com, inc.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.salesforce.mobilesyncexplorerkotlintemplate.model.contacts

import com.salesforce.androidsdk.accounts.UserAccount
import com.salesforce.mobilesyncexplorerkotlintemplate.core.repos.SObjectSyncableRepo
import com.salesforce.mobilesyncexplorerkotlintemplate.core.repos.SObjectSyncableRepoBase
import com.salesforce.mobilesyncexplorerkotlintemplate.core.salesforceobject.SObjectDeserializer
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers

/**
 * The basic implementation of [SObjectSyncableRepo] for the [ContactObject] SObject.
 */
class DefaultContactsRepo(
    account: UserAccount,
    ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : SObjectSyncableRepoBase<ContactObject>(account = account, ioDispatcher = ioDispatcher) {

    override val deserializer: SObjectDeserializer<ContactObject> = ContactObject.Companion
    override val soupName: String = CONTACTS_SOUP_NAME
    override val syncDownName: String = SYNC_DOWN_CONTACTS
    override val syncUpName: String = SYNC_UP_CONTACTS

    companion object {
        const val CONTACTS_SOUP_NAME = "contacts"
        const val SYNC_DOWN_CONTACTS = "syncDownContacts"
        const val SYNC_UP_CONTACTS = "syncUpContacts"
    }
}

typealias ContactsRepo = SObjectSyncableRepo<ContactObject>
